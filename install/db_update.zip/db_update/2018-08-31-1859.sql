ALTER TABLE `event_list` 
ADD COLUMN `event_program` TEXT NULL AFTER `event_descr`;
