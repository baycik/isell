ALTER TABLE `isell_db`.`plugin_list` 
ADD COLUMN `plugin_json_data` JSON NULL AFTER `plugin_settings`;