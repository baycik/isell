UPDATE `isell_db`.`document_view_types` SET `view_efield_labels` = '{\r 	\"reciever\":{\"label\":\"Грузополучатель\",\"type\":\"company_id\"},\r 	\"place_count\":\"Всего мест\",\r                 \"supplier\":{\"label\":\"Грузоотправитель\",\"type\":\"company_id\"},\r                 \"reason\":\"Основание\",\r 	\"transport_bill_num\":\"ТТН №\",\r 	\"reason_num\":\"Основание №\",\r                 \"transport_bill_date\":{\"label\":\"ТТН дата\",\"type\":\"date\"},\r 	\"reason_date\":{\"label\":\"Основание дата\",\"type\":\"date\"}\r } ' WHERE (`view_type_id` = '133');

/**
 * Author:  Baycik
 * Created: 25 февр. 2020 г.
 */

