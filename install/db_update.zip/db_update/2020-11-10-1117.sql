ALTER TABLE `plugin_campaign_bonus` 
ADD COLUMN `product_class_filter` VARCHAR(2) NULL AFTER `product_type_filter`;
