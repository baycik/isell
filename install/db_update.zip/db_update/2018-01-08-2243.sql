ALTER TABLE `plugin_rpt_market_result` 
DROP COLUMN `analyse_group`,
DROP COLUMN `analyse_type`;


ALTER TABLE `plugin_market_rpt_entries` 
DROP COLUMN `analyse_group`,
DROP COLUMN `analyse_type`;
