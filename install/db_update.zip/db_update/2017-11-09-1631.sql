DROP VIEW `document_view_registry`;
DROP VIEW `stat_annual_sellbuy`;
DROP VIEW `stat_annual_sold`;
DROP VIEW `stat_brand_comp_sold`;
DROP VIEW `stat_brand_sold`;
DROP VIEW `stat_sell_analyse`;
DROP VIEW `stock_entry_view`;