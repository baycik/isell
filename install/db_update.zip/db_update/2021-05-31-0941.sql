ALTER TABLE `document_list` 
ADD COLUMN `doc_deferment` INT NULL AFTER `doc_status_id`;
