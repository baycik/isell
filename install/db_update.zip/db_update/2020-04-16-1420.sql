ALTER TABLE `document_list` 
CHANGE COLUMN `doc_num` `doc_num` VARCHAR(15) NOT NULL ;
