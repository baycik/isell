ALTER TABLE `companies_list` 
ADD COLUMN `company_accountant` VARCHAR(45) NULL AFTER `company_director_title`;
