ALTER TABLE `event_list` 
DROP FOREIGN KEY `userid`;