ALTER TABLE `price_list` 
CHANGE COLUMN `label` `label` VARCHAR(45) NOT NULL COMMENT 'Категория цен' ;
