ALTER TABLE `supply_list` 
ADD INDEX `product_code_INDEX` (`product_code` ASC);
