UPDATE `document_view_types` SET `view_tpl` = 'ru/doc/torg12.html,ru/doc/torg12.xlsx' WHERE (`view_type_id` = '133');
