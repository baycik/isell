ALTER TABLE `companies_list` 
CHANGE COLUMN `price_label` `price_label` VARCHAR(45) NOT NULL ;
