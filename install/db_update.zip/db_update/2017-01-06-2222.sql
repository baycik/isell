/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Baycik
 * Created: Jan 6, 2017
 */

ALTER TABLE `document_list` 
CHANGE COLUMN `doc_type` `doc_type` VARCHAR(10) NOT NULL ;
