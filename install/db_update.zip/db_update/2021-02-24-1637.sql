UPDATE `document_view_types` SET `view_tpl` = 'ru/doc/schet-faktura.html,ru/doc/schet-faktura.xlsx' WHERE (`view_type_id` = '140');
