ALTER TABLE `document_entries` 
ADD COLUMN `breakeven_price` DOUBLE NOT NULL AFTER `self_price`;
