ALTER TABLE `stock_entries` 
ADD INDEX `fetch_count_index` (`fetch_count` DESC);