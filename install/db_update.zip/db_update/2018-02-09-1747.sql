ALTER TABLE `acc_trans_names` 
ADD COLUMN `trans_label` VARCHAR(45) NULL AFTER `user_level`;
