ALTER TABLE `user_list` 
ADD COLUMN `user_email` VARCHAR(45) NULL AFTER `user_phone`;
