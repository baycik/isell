ALTER TABLE `event_list` 
CHANGE COLUMN `event_note` `event_note` VARCHAR(255) NOT NULL COMMENT '' ;