ALTER TABLE `supply_list` 
ADD INDEX `supply_code_INDEX` (`supply_code` ASC);
