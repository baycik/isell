ALTER TABLE `isell_db`.`attribute_values` 
ADD INDEX `attribute_value_hash_index` (`attribute_value_hash` ASC);

