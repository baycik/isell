ALTER TABLE `log_list` 
CHANGE COLUMN `message` `message` VARCHAR(1000) NULL DEFAULT NULL COMMENT 'Сообщение ' ;
