INSERT INTO `document_status_list` (`doc_status_id`, `status_code`, `status_description`, `user_level`, `commited_only`) VALUES ('4', 'completed', 'Завершен', '2', '1');
