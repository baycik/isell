ALTER TABLE `companies_list` 
ADD COLUMN `expense_label` VARCHAR(45) NULL AFTER `price_label`;
