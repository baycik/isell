ALTER TABLE `user_list` 
ADD COLUMN `user_tax_id` VARCHAR(45) NULL AFTER `user_is_staff`;
