ALTER TABLE `document_list` 
ADD COLUMN `doc_handler` VARCHAR(45) NULL AFTER `doc_type`;
