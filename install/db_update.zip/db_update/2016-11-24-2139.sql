/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Baycik
 * Created: Nov 24, 2016
 */
ALTER TABLE `document_list` 
DROP FOREIGN KEY `fk_document_list_document_types1`;

