ALTER TABLE `log_list` 
CHANGE COLUMN `message` `message` TEXT NULL DEFAULT NULL COMMENT 'Сообщение ' ;
