ALTER TABLE `document_entries` 
CHANGE COLUMN `product_quantity` `product_quantity` DOUBLE NOT NULL ;

ALTER TABLE `isell_db`.`stock_entries` 
CHANGE COLUMN `product_quantity` `product_quantity` DOUBLE NOT NULL ;
