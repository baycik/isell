INSERT INTO `document_types` (`doc_type`, `doc_type_name`, `icon_name`) VALUES ('-1', 'Возврат от покупателя', 'sell');
INSERT INTO `document_types` (`doc_type`, `doc_type_name`, `icon_name`) VALUES ('-2', 'Возврат поставщику', 'buy');
