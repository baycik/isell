ALTER TABLE `acc_tree` 
ADD COLUMN `top_id` INT NULL AFTER `use_clientbank`;
