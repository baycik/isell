ALTER TABLE `plugin_list` 
ADD COLUMN `trigger_after` TEXT NULL AFTER `trigger_before`;