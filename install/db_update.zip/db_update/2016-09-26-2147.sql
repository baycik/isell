/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Baycik
 * Created: Sep 26, 2016
 */

ALTER TABLE `pref_list` 
ADD COLUMN `pref_int` INT NOT NULL AFTER `pref_value`;
