ALTER TABLE `event_list` 
ADD INDEX `label` (`event_label` ASC);
