ALTER TABLE `companies_list` 
ADD COLUMN `company_director_title` VARCHAR(45) NOT NULL AFTER `company_director`;
