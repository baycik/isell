ALTER TABLE `user_list` 
ADD COLUMN `last_activity` DATETIME NULL AFTER `user_assigned_stat`;
