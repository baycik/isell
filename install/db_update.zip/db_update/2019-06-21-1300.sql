ALTER TABLE `supply_list` 
ADD COLUMN `supply_leftover` INT(11) NOT NULL AFTER `supply_name`;