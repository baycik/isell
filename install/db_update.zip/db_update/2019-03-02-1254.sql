ALTER TABLE `stock_entries` 
CHANGE COLUMN `product_reserve` `product_reserved` DOUBLE NULL DEFAULT NULL;
