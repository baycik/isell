ALTER TABLE `document_list` 
ADD COLUMN `doc_status_id` INT NULL AFTER `doc_settings`;
