UPDATE `document_view_types` SET `view_efield_labels` = '{\"personal_interest\":\"Личный интерес%\"}' WHERE (`view_type_id` = '134');
