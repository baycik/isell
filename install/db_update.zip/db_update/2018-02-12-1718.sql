INSERT INTO `acc_trans_status` (`trans_status`, `code`, `descr`) VALUES ('6', 'unpayedsq', 'Невыплачено');
INSERT INTO `acc_trans_status` (`trans_status`, `code`, `descr`) VALUES ('7', 'partlysq', 'Частично выплачено');
INSERT INTO `acc_trans_status` (`trans_status`, `code`, `descr`) VALUES ('8', 'payedsq', 'Выплачено');
INSERT INTO `acc_trans_status` (`trans_status`, `code`, `descr`) VALUES ('9', 'closedsq', 'Выплачено');
INSERT INTO `acc_trans_status` (`trans_status`, `code`) VALUES ('10', 'closingsq');
