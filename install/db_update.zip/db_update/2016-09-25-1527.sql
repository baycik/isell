ALTER TABLE `pref_list` 
DROP FOREIGN KEY `fk_pref_list_companies_list1`;
