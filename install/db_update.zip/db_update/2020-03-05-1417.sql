ALTER TABLE `document_view_list` 
CHANGE COLUMN `view_num` `view_num` VARCHAR(20) NOT NULL ;
